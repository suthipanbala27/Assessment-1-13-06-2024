import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://buhs.ac.in/WP/BHUEDU/History.aspx')

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/a_About Us'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/div_Home                                   _73c315'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/div_Login_responsive-logobar menu-button'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/a_About Us_1'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/a_About Us_1'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/a_Honble Chancellor'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/a_httpscm.bihar.gov.inusershome.aspx'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/img_concat(Hon, , ble Chief Minister, Bihar_7196fb'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/a_About Us'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/a_Authorities of University'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/a_Senate'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/a_Executive Council'))

WebUI.click(findTestObject('Object Repository/Bihar_UnioversityHS_Home/Page_Bihar University Of Health Sciences/div_Board Of Planning'))

WebUI.closeBrowser()

