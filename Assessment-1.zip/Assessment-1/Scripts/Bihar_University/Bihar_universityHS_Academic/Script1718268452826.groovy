import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://buhs.ac.in/WP/BHUEDU/Coursesyllabus.aspx')

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/td_Syllabus of Bachelor of Physiotherapy'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/a_Download'))

WebUI.switchToWindowTitle('Bihar University Of Health Sciences')

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/a_Download_1'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/a_Faculties'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/a_Academic'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/a_Courses'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/p_Estd. 2022'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/a_On Going Research Project'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/span_On Going Research Project'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/div_Home                                   _73c315'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/a_Research'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/a_Research With Us'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/input_Your profile within 200 words_ctl00Co_0da843'))

WebUI.click(findTestObject('Object Repository/Page_Bihar University Of Health Sciences/input_Your profile within 200 words_ctl00Co_e72163'))

WebUI.closeBrowser()

