<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Home                                   _73c315</name>
   <tag></tag>
   <elementGuidId>c0f6f63f-42be-4fd7-bbf1-49464b03e8f6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.responsive-header</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='aspnetForm']/section[2]/div/div/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>.responsive-header</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>a44aa742-12f4-411e-abfc-03c60c3a9f63</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>responsive-header</value>
      <webElementGuid>aef1a1ea-de0c-426a-8d49-c8ca275c1548</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                        
                            
                                
                            
                        
                        
                            
                            
                            
                                
                                    Home
                                

                                 
           
          About Us 
          
          

            History

            
                                            Aim
            
                                            Objectives

            
                                            About Our Logo
          
            
                                            Hon'ble Chancellor
              
            
           
                                            University Officers
            
                                            Authorities of University
              
                                            Organization Structure
              
                                            Directory
              
          
        


                            


                                
           
          Affilation 
          
          
            Affiliation Process
            Affiliation Notification
              Forms
              Affiliated College
            
              
          
        
                                 
           
          Academic 
          
          
           
            
                                            Faculties 

            
                                            Courses
               
                                            Download Syllabus
          
          
        

    
                                    
                                        Research 
                                    
                                    
                                        
                                            On Going Research Project 
                                        
                                            Research With Us
                                    
                                


                                
                                    
                                        Student Corner 
                                    
                                    
                                        
                                            Examination

                                        
                                        
                                            Registration

                                        
                                    
                                
                                
                                    
                                        Downloads 
                                    
                                    
                                        
                                            Act
                                        
                                            Notification Circular
                                        
                                        
                                            Office Order
                                        
                                            Forms
                                    
                                

                                
                                    Notice Board
                                    
                                
                                 
                                    Tenders
                                    
                                
                                
                                    Gallery
                                    
                                        
                                            Photo Gallery

                                    
                                
                               

                                
                                    Contacts
                                    
                                        
                                            Key Contacts
                                    
                                
                                 
                                    Recruitment
                                    
                                

                                
                                    Login
                                
                            


                        
                    </value>
      <webElementGuid>d2efd2e1-a02c-4295-8d8c-238b0353ec84</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;aspnetForm&quot;)/section[@class=&quot;sticky&quot;]/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;responsive-header&quot;]</value>
      <webElementGuid>3b6a248d-5046-4a8b-bff5-11961450bfdd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/section[2]/div/div/div[2]</value>
      <webElementGuid>84ef886d-b55c-436d-9c1d-5088ab294a77</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::div[1]</value>
      <webElementGuid>68ce6b62-2238-45ba-818d-d7a775307446</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CHANAKYA-BUHS'])[1]/following::div[1]</value>
      <webElementGuid>74e1528f-bf07-41e1-b6d0-5631aa5ac75a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/div/div[2]</value>
      <webElementGuid>90ec158d-57e7-4cdb-be4c-25dfebd06c8e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;
                        
                        
                            
                                
                            
                        
                        
                            
                            
                            
                                
                                    Home
                                

                                 
           
          About Us 
          
          

            History

            
                                            Aim
            
                                            Objectives

            
                                            About Our Logo
          
            
                                            Hon&quot; , &quot;'&quot; , &quot;ble Chancellor
              
            
           
                                            University Officers
            
                                            Authorities of University
              
                                            Organization Structure
              
                                            Directory
              
          
        


                            


                                
           
          Affilation 
          
          
            Affiliation Process
            Affiliation Notification
              Forms
              Affiliated College
            
              
          
        
                                 
           
          Academic 
          
          
           
            
                                            Faculties 

            
                                            Courses
               
                                            Download Syllabus
          
          
        

    
                                    
                                        Research 
                                    
                                    
                                        
                                            On Going Research Project 
                                        
                                            Research With Us
                                    
                                


                                
                                    
                                        Student Corner 
                                    
                                    
                                        
                                            Examination

                                        
                                        
                                            Registration

                                        
                                    
                                
                                
                                    
                                        Downloads 
                                    
                                    
                                        
                                            Act
                                        
                                            Notification Circular
                                        
                                        
                                            Office Order
                                        
                                            Forms
                                    
                                

                                
                                    Notice Board
                                    
                                
                                 
                                    Tenders
                                    
                                
                                
                                    Gallery
                                    
                                        
                                            Photo Gallery

                                    
                                
                               

                                
                                    Contacts
                                    
                                        
                                            Key Contacts
                                    
                                
                                 
                                    Recruitment
                                    
                                

                                
                                    Login
                                
                            


                        
                    &quot;) or . = concat(&quot;
                        
                        
                            
                                
                            
                        
                        
                            
                            
                            
                                
                                    Home
                                

                                 
           
          About Us 
          
          

            History

            
                                            Aim
            
                                            Objectives

            
                                            About Our Logo
          
            
                                            Hon&quot; , &quot;'&quot; , &quot;ble Chancellor
              
            
           
                                            University Officers
            
                                            Authorities of University
              
                                            Organization Structure
              
                                            Directory
              
          
        


                            


                                
           
          Affilation 
          
          
            Affiliation Process
            Affiliation Notification
              Forms
              Affiliated College
            
              
          
        
                                 
           
          Academic 
          
          
           
            
                                            Faculties 

            
                                            Courses
               
                                            Download Syllabus
          
          
        

    
                                    
                                        Research 
                                    
                                    
                                        
                                            On Going Research Project 
                                        
                                            Research With Us
                                    
                                


                                
                                    
                                        Student Corner 
                                    
                                    
                                        
                                            Examination

                                        
                                        
                                            Registration

                                        
                                    
                                
                                
                                    
                                        Downloads 
                                    
                                    
                                        
                                            Act
                                        
                                            Notification Circular
                                        
                                        
                                            Office Order
                                        
                                            Forms
                                    
                                

                                
                                    Notice Board
                                    
                                
                                 
                                    Tenders
                                    
                                
                                
                                    Gallery
                                    
                                        
                                            Photo Gallery

                                    
                                
                               

                                
                                    Contacts
                                    
                                        
                                            Key Contacts
                                    
                                
                                 
                                    Recruitment
                                    
                                

                                
                                    Login
                                
                            


                        
                    &quot;))]</value>
      <webElementGuid>0e763f82-ace5-41dd-a362-b75b9436891d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
