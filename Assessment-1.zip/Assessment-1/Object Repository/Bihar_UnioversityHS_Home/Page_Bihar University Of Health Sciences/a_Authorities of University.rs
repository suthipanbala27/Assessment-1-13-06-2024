<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Authorities of University</name>
   <tag></tag>
   <elementGuidId>2d744fef-f666-41ee-b9bd-ea89c6e2273e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(7) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='aspnetForm']/section[2]/div/div/div/div/ul/li[2]/ul/li[7]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Authorities of University&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>23a9a091-d2ef-48b5-867a-4aed94e149ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>Authoritiesofuniversity.aspx</value>
      <webElementGuid>075911fa-bee5-49f7-8487-d5e736a6cba1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                            Authorities of University</value>
      <webElementGuid>8b3c2408-2782-4df2-a10a-3b4b556485b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;aspnetForm&quot;)/section[@class=&quot;sticky fixed&quot;]/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;content&quot;]/ul[@class=&quot;jetmenu&quot;]/li[@class=&quot;dropdown open&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[7]/a[1]</value>
      <webElementGuid>b96f8f9c-1027-4e7b-8f2a-67ba7d786d5e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/section[2]/div/div/div/div/ul/li[2]/ul/li[7]/a</value>
      <webElementGuid>d0a7221c-b371-4d15-b42d-d94c7fc250b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Authorities of University')]</value>
      <webElementGuid>f4cb48ee-d3f7-4cf3-a8e4-c7f819a88395</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='University Officers'])[1]/following::a[1]</value>
      <webElementGuid>e061bf09-1643-43c0-bb87-8089f17256c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Organization Structure'])[1]/preceding::a[1]</value>
      <webElementGuid>79962bc9-a18b-41be-b3c7-6fa6f9cfca17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Directory'])[1]/preceding::a[2]</value>
      <webElementGuid>55f847bc-7bc4-4dcc-8e99-3616b6e5392c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Authorities of University']/parent::*</value>
      <webElementGuid>9a57af20-959a-489f-a92d-f97ca0b00a6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'Authoritiesofuniversity.aspx')]</value>
      <webElementGuid>804f79ed-6e21-446c-9daa-755fdca969f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li[7]/a</value>
      <webElementGuid>1ea363ba-7fce-4153-9fe8-0ce069fd706b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'Authoritiesofuniversity.aspx' and (text() = '
                                            Authorities of University' or . = '
                                            Authorities of University')]</value>
      <webElementGuid>64120d86-97d8-4feb-8c47-f80d4d954e6e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
