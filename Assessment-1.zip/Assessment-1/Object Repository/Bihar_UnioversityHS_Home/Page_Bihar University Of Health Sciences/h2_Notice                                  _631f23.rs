<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Notice                                  _631f23</name>
   <tag></tag>
   <elementGuidId>448b29cd-2ce7-409d-9b52-51b61cb9e9f9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='aspnetForm']/div[4]/div[2]/div/div[2]/div/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Notice Board&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>53aef44c-34f6-472f-8ec3-9d3eab608049</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title</value>
      <webElementGuid>3c95503c-2597-418b-8b0a-d6d5429db0d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            Notice
                            
                                Board
                            </value>
      <webElementGuid>52db3b6a-b8fd-4298-a8b3-ae9a3486c12a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;aspnetForm&quot;)/div[4]/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 col-md-6&quot;]/div[@class=&quot;panel-box-info&quot;]/h2[@class=&quot;title&quot;]</value>
      <webElementGuid>e379fe37-ace4-4954-b83f-45289e4bdea0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/div[4]/div[2]/div/div[2]/div/h2</value>
      <webElementGuid>773f5448-004b-4d83-9c67-eeb4738bacf9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='More Info'])[1]/following::h2[1]</value>
      <webElementGuid>b5e5edc5-6c9c-4160-8c14-17c5913d451c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Registration for UG PG Students is being extended till 20.02.2024'])[1]/following::h2[1]</value>
      <webElementGuid>a293f5cc-9e17-4490-b622-30e2fb3dd457</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Notice']/parent::*</value>
      <webElementGuid>b1fea994-3b63-4138-8ea3-68928c51c807</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/h2</value>
      <webElementGuid>e225160e-c061-49c7-9942-4e9dc176230b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
                            Notice
                            
                                Board
                            ' or . = '
                            Notice
                            
                                Board
                            ')]</value>
      <webElementGuid>c66b9c09-a431-4851-b80b-694756f1ba74</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
