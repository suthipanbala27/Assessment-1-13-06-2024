<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_1.                                     _668bff</name>
   <tag></tag>
   <elementGuidId>6383e741-9644-4f91-a942-dca3e3279285</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul > div</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Div1']/ul/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;1. All colleges affiliated with BUHS, Patna is hereby informed that name of BUHS&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9f0dc127-7856-4b07-b315-451be363e1c4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                
                                    
                                        1.
                                    
                                    
                                        All colleges affiliated with BUHS, Patna is hereby informed that name of BUHS, Patna has been added in AISH Portal from the session 2023-24 onwards
                                    
                                </value>
      <webElementGuid>e8f82e68-5805-409b-a044-610173c936f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Div1&quot;)/ul[1]/div[1]</value>
      <webElementGuid>650594ba-624e-45fb-ba98-f6da04f44f66</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Div1']/ul/div</value>
      <webElementGuid>a3cb86ee-4b92-4791-94fb-563c6bf57f16</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News'])[1]/following::div[3]</value>
      <webElementGuid>3a5e2e51-1c49-48dc-9d0a-d88f7ab5f86d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='.']/parent::*</value>
      <webElementGuid>286e5c4c-216e-44b0-8594-046f148c81d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ul/div</value>
      <webElementGuid>3fd8f9dc-ce07-4cfa-9b02-06816cf8721c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                
                                    
                                        1.
                                    
                                    
                                        All colleges affiliated with BUHS, Patna is hereby informed that name of BUHS, Patna has been added in AISH Portal from the session 2023-24 onwards
                                    
                                ' or . = '
                                
                                    
                                        1.
                                    
                                    
                                        All colleges affiliated with BUHS, Patna is hereby informed that name of BUHS, Patna has been added in AISH Portal from the session 2023-24 onwards
                                    
                                ')]</value>
      <webElementGuid>b167d138-3d38-4bbe-9dc9-477d43e9d973</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
