<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Board Of Planning</name>
   <tag></tag>
   <elementGuidId>4008db60-cfd8-4db4-883b-b3d8b3aba845</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='accordion']/div[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;Board Of Planning&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>f84e58fd-20da-428a-8046-b086c53fedfc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>panel panel-default</value>
      <webElementGuid>e2733856-ce14-4f4e-b078-9226223a8805</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            
                
                    
                        
                        Board Of Planning
                    
                
            
            
                
                    
                
            
        </value>
      <webElementGuid>0a8fd1d9-e592-4ea1-a3be-83e96c90fb7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;accordion&quot;)/div[@class=&quot;panel panel-default&quot;]</value>
      <webElementGuid>e2156fc7-d062-4f21-9476-e2d8f736250f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='accordion']/div[5]</value>
      <webElementGuid>c3114873-4a6b-44a3-baaa-41a6b9c9207d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]</value>
      <webElementGuid>b07b7d20-a6d8-4e82-a34c-2587db22250e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
            
                
                    
                        
                        Board Of Planning
                    
                
            
            
                
                    
                
            
        ' or . = '
            
                
                    
                        
                        Board Of Planning
                    
                
            
            
                
                    
                
            
        ')]</value>
      <webElementGuid>c62cfa0d-be66-4bfe-9e1f-e44b3cdc5542</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
