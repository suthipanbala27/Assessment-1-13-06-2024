<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Honble Chancellor</name>
   <tag></tag>
   <elementGuidId>f0cb2584-e40d-42c8-bdf2-96bb5438179e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.dropdown.menu-item-has-children > ul.dropdown-menu > li:nth-of-type(5) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='aspnetForm']/section[2]/div/div/div[2]/div[2]/ul/li[2]/ul/li[5]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Hon'ble Chancellor&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>bab867f9-655b-4f89-ba0f-d1657339d4aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>Organation.aspx</value>
      <webElementGuid>f3f4b57e-3641-4c2f-9d0b-b85e538092b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                            Hon'ble Chancellor</value>
      <webElementGuid>c92870bc-5bf7-4737-915b-35c742665c3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;aspnetForm&quot;)/section[@class=&quot;sticky&quot;]/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;responsive-header&quot;]/div[@class=&quot;responsive-menu slidein&quot;]/ul[@class=&quot;ints-ul&quot;]/li[@class=&quot;dropdown menu-item-has-children&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[5]/a[1]</value>
      <webElementGuid>967b99f1-ccd8-406d-9ed9-60a8bc1dd26f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/section[2]/div/div/div[2]/div[2]/ul/li[2]/ul/li[5]/a</value>
      <webElementGuid>69b3c1b4-607e-46ed-a14b-5e41e59fb534</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Our Logo'])[2]/following::a[1]</value>
      <webElementGuid>c6647e2e-5093-4f75-9d61-0527c4717537</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Objectives'])[2]/following::a[2]</value>
      <webElementGuid>d616d7da-45a1-4d71-b2df-9cb8129bde60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Organization Structure'])[2]/preceding::a[3]</value>
      <webElementGuid>a66f4cf0-7f67-4db9-90cf-9d77fab230e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Research With Us'])[2]/preceding::a[16]</value>
      <webElementGuid>354fd209-7e37-4491-ba66-df68a4334368</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'Organation.aspx')])[2]</value>
      <webElementGuid>31582bab-edbc-485b-a1d2-5026b5fd5cc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[2]/ul/li[5]/a</value>
      <webElementGuid>dd773cb8-6eab-4c75-b128-cd4823386da9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'Organation.aspx' and (text() = concat(&quot;
                                            Hon&quot; , &quot;'&quot; , &quot;ble Chancellor&quot;) or . = concat(&quot;
                                            Hon&quot; , &quot;'&quot; , &quot;ble Chancellor&quot;))]</value>
      <webElementGuid>a59c84f9-b3a3-4d41-b88d-748b211bcf54</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
