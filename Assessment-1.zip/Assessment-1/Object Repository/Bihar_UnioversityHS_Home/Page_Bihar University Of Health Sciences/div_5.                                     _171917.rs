<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_5.                                     _171917</name>
   <tag></tag>
   <elementGuidId>bfc1debf-ada8-4003-a9d9-1fb7fcb30d97</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul > div:nth-of-type(5)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Div1']/ul/div[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;5. Online Registration for UG PG Students is being extended till 05.03.2024&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>7bab3f21-c03e-4056-b591-b5ab3843688f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                
                                    
                                        5.
                                    
                                    
                                        Online Registration for UG PG Students is being extended till 05.03.2024
                                    
                                </value>
      <webElementGuid>927fea76-cf78-40f3-b98f-fa96d7fa80e2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Div1&quot;)/ul[1]/div[5]</value>
      <webElementGuid>3f387cc8-3c29-47f5-9327-99807dc71d21</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Div1']/ul/div[5]</value>
      <webElementGuid>30b9b809-d1e5-4f43-96a2-4fa134c58179</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Registration with LATE FINE for UG PG Students is being extended till 31.03.2024'])[1]/following::div[1]</value>
      <webElementGuid>2d6a3a29-29b4-4e7a-8bae-e3f641a90338</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ul/div[5]</value>
      <webElementGuid>7d9daf75-72cf-4e03-920d-67c913bcd025</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                
                                    
                                        5.
                                    
                                    
                                        Online Registration for UG PG Students is being extended till 05.03.2024
                                    
                                ' or . = '
                                
                                    
                                        5.
                                    
                                    
                                        Online Registration for UG PG Students is being extended till 05.03.2024
                                    
                                ')]</value>
      <webElementGuid>3c832e13-7435-47da-8ea5-fac65c447fde</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
