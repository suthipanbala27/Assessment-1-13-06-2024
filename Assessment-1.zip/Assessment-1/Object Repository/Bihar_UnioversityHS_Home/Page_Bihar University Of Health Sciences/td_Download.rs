<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Download</name>
   <tag></tag>
   <elementGuidId>c5e3c655-3743-454c-9020-8d880a98ca76</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>table.cols-md-12.table > tbody > tr > td:nth-of-type(3)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='aspnetForm']/div[4]/section/div/div[3]/table/tbody/tr/td[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;07 Jun 2024 Notification No. 603 dated 07.06.2024 - Provisional Affiliation of Govt. Pharmacy Colleges/Institutions Download&quot;i] >> internal:role=cell >> nth=2</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>48d46a69-a282-4e77-ad99-8e6fa39e1ee1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 
                                        
                                             Download
                                    
                                    </value>
      <webElementGuid>3c741008-6500-4934-a3a3-1ff8d9a29b60</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;aspnetForm&quot;)/div[4]/section[@class=&quot;pad30&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/table[@class=&quot;cols-md-12 table&quot;]/tbody[1]/tr[1]/td[3]</value>
      <webElementGuid>2740b9a8-2468-4288-81c6-ad485a98132b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/div[4]/section/div/div[3]/table/tbody/tr/td[3]</value>
      <webElementGuid>21ee2ce2-9220-4166-a0af-cb8938b016ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Document'])[1]/following::td[3]</value>
      <webElementGuid>b68023f0-abc0-4c22-a1c4-56742e09128b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Heading'])[1]/following::td[3]</value>
      <webElementGuid>d412f684-66af-4424-81fe-a44a8326b58a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/table/tbody/tr/td[3]</value>
      <webElementGuid>c3b1aacb-a24c-4800-a9a2-1934c924cf92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = ' 
                                        
                                             Download
                                    
                                    ' or . = ' 
                                        
                                             Download
                                    
                                    ')]</value>
      <webElementGuid>d56642ee-f1b6-4115-8267-893c2204594a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
