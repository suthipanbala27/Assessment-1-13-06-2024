<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_On Going Research Project</name>
   <tag></tag>
   <elementGuidId>e431accf-f540-42fb-a7f3-2b64ce24d041</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='aspnetForm']/section[2]/div/div/div/div/ul/li[5]/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;On Going Research Project&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5becdb2d-c8b1-4908-9469-0dfea277a164</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>Research_Project.aspx</value>
      <webElementGuid>3758df34-32c9-42b0-8b13-d68b71154977</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                            On Going Research Project</value>
      <webElementGuid>a4402e2f-fb58-41dc-96c4-7942dacd3159</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;aspnetForm&quot;)/section[@class=&quot;sticky&quot;]/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;content&quot;]/ul[@class=&quot;jetmenu&quot;]/li[@class=&quot;dropdown&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[1]/a[1]</value>
      <webElementGuid>d62dbb1d-f20f-4005-8a25-1018cd56d782</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/section[2]/div/div/div/div/ul/li[5]/ul/li/a</value>
      <webElementGuid>154100dc-534c-41b2-b2fc-98c2ff1855cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'On Going Research Project')]</value>
      <webElementGuid>19a8afb7-8f9b-4044-b8cb-b57ee1a442cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download Syllabus'])[1]/following::a[2]</value>
      <webElementGuid>615cbbbd-5c8c-494f-a8c9-1c1105ef81f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Courses'])[1]/following::a[3]</value>
      <webElementGuid>50eb3795-46e4-4904-a70d-66c454983fac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Research With Us'])[1]/preceding::a[1]</value>
      <webElementGuid>4d635b56-9316-48b2-a843-cb7b20260802</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Examination'])[1]/preceding::a[3]</value>
      <webElementGuid>1a065ddc-faa9-476d-86df-e97088e153c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='On Going Research Project']/parent::*</value>
      <webElementGuid>8bce0499-ecad-4fc4-9b96-160db4d67fb8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'Research_Project.aspx')]</value>
      <webElementGuid>01bdec13-5690-40af-a4a3-031c5702fcfe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/ul/li/a</value>
      <webElementGuid>d460fb04-36ed-454a-8831-916d9b930452</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'Research_Project.aspx' and (text() = '
                                            On Going Research Project' or . = '
                                            On Going Research Project')]</value>
      <webElementGuid>b6283b27-91f6-4ca1-be3d-dd1b368bd49c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
