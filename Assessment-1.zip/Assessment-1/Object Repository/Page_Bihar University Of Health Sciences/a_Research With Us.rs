<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Research With Us</name>
   <tag></tag>
   <elementGuidId>d1a84cba-fb2b-4bce-8da6-f1f9bd8b536f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.dropdown.open > ul.dropdown-menu > li:nth-of-type(2) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='aspnetForm']/section[2]/div/div/div/div/ul/li[5]/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Research With Us&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>366ac240-98f4-4f55-a915-67892fd898d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>Research_Withus.aspx</value>
      <webElementGuid>8cbdb6f8-2652-44ea-a4fa-19aa069e785b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                            Research With Us</value>
      <webElementGuid>67657c3c-c4b8-48fa-ab89-9fec313a709b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;aspnetForm&quot;)/section[@class=&quot;sticky&quot;]/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;content&quot;]/ul[@class=&quot;jetmenu&quot;]/li[@class=&quot;dropdown open&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[2]/a[1]</value>
      <webElementGuid>5beb62fb-28e8-45bc-a940-ef75c952e3c7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/section[2]/div/div/div/div/ul/li[5]/ul/li[2]/a</value>
      <webElementGuid>da39a638-1470-4bef-ab13-af690fb5a699</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Research With Us')]</value>
      <webElementGuid>29bf6d6f-7203-4696-bf9b-a690b56d43ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='On Going Research Project'])[1]/following::a[1]</value>
      <webElementGuid>ed5c325d-b733-4625-bed2-4ca26abe17cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download Syllabus'])[1]/following::a[3]</value>
      <webElementGuid>eb127e87-e860-4aa0-ba0d-872bf202f142</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Examination'])[1]/preceding::a[2]</value>
      <webElementGuid>6c731c15-9325-4fdc-bb2b-a58a70df2ba1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Registration'])[1]/preceding::a[3]</value>
      <webElementGuid>521cf39e-2de4-4721-aacb-0a1740088d76</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Research With Us']/parent::*</value>
      <webElementGuid>ed334a4f-e12b-4b47-8eb4-ea511ebc8c35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'Research_Withus.aspx')]</value>
      <webElementGuid>8577e811-09d6-4b1f-9b26-17ba8f0f69c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/ul/li[2]/a</value>
      <webElementGuid>0c0484a8-61b9-4090-897a-58b9999a47d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'Research_Withus.aspx' and (text() = '
                                            Research With Us' or . = '
                                            Research With Us')]</value>
      <webElementGuid>36400e62-39da-4186-845c-751b2c23d784</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
