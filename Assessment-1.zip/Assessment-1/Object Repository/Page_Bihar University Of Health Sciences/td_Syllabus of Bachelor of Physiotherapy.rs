<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Syllabus of Bachelor of Physiotherapy</name>
   <tag></tag>
   <elementGuidId>10311075-d808-40ca-9cfb-7e0cd6378e7a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>td:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='ctl00_ContentPlaceHolder1_grdcollegeeng']/tbody/tr[2]/td[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Syllabus of Bachelor of Physiotherapy&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>70a6c30f-f3bb-4958-97e7-dde0bb6a56df</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>align</name>
      <type>Main</type>
      <value>left</value>
      <webElementGuid>f83a9133-ce33-40fa-bce6-9bb0606b56af</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                
                                
                                Syllabus of Bachelor of Physiotherapy
                            </value>
      <webElementGuid>2b78c47d-172b-40fe-ba77-1a2dbcfe937f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ctl00_ContentPlaceHolder1_grdcollegeeng&quot;)/tbody[1]/tr[2]/td[2]</value>
      <webElementGuid>f599cd8f-823e-4a27-9f00-4aae4f76678a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='ctl00_ContentPlaceHolder1_grdcollegeeng']/tbody/tr[2]/td[2]</value>
      <webElementGuid>bba763a1-31fc-46d0-ad64-a9b267fc9199</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download Syllabus'])[3]/following::td[2]</value>
      <webElementGuid>c71ea895-1afa-4dac-aba7-eacba8f875ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Course Name'])[1]/following::td[2]</value>
      <webElementGuid>eb23cfeb-229d-49b2-a54a-0ff64a77e54e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]</value>
      <webElementGuid>f879c037-ba35-4862-8bdb-daa4804d6ab1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = '
                                
                                
                                Syllabus of Bachelor of Physiotherapy
                            ' or . = '
                                
                                
                                Syllabus of Bachelor of Physiotherapy
                            ')]</value>
      <webElementGuid>eba316f4-133e-4194-b44c-3bf412548134</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
