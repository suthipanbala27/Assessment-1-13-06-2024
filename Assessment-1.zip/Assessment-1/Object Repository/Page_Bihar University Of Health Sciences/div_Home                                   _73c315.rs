<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Home                                   _73c315</name>
   <tag></tag>
   <elementGuidId>4d8cef10-486b-4b80-89f2-2dc564b44f15</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.responsive-header</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='aspnetForm']/section[2]/div/div/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>.responsive-header</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d4ec283b-14c7-41b5-8377-1a2b63dd4b21</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>responsive-header</value>
      <webElementGuid>d1b23894-f837-4c85-b334-a972d6f09788</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                        
                            
                                
                            
                        
                        
                            
                            
                            
                                
                                    Home
                                

                                 
           
          About Us 
          
          

            History

            
                                            Aim
            
                                            Objectives

            
                                            About Our Logo
          
            
                                            Hon'ble Chancellor
              
            
           
                                            University Officers
            
                                            Authorities of University
              
                                            Organization Structure
              
                                            Directory
              
          
        


                            


                                
           
          Affilation 
          
          
            Affiliation Process
            Affiliation Notification
              Forms
              Affiliated College
            
              
          
        
                                 
           
          Academic 
          
          
           
            
                                            Faculties 

            
                                            Courses
               
                                            Download Syllabus
          
          
        

    
                                    
                                        Research 
                                    
                                    
                                        
                                            On Going Research Project 
                                        
                                            Research With Us
                                    
                                


                                
                                    
                                        Student Corner 
                                    
                                    
                                        
                                            Examination

                                        
                                        
                                            Registration

                                        
                                    
                                
                                
                                    
                                        Downloads 
                                    
                                    
                                        
                                            Act
                                        
                                            Notification Circular
                                        
                                        
                                            Office Order
                                        
                                            Forms
                                    
                                

                                
                                    Notice Board
                                    
                                
                                 
                                    Tenders
                                    
                                
                                
                                    Gallery
                                    
                                        
                                            Photo Gallery

                                    
                                
                               

                                
                                    Contacts
                                    
                                        
                                            Key Contacts
                                    
                                
                                 
                                    Recruitment
                                    
                                

                                
                                    Login
                                
                            


                        
                    </value>
      <webElementGuid>879d6366-96e6-4d09-84cd-3679041e4701</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;aspnetForm&quot;)/section[@class=&quot;sticky&quot;]/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;responsive-header&quot;]</value>
      <webElementGuid>64d5c1d0-0edb-4b2b-8db9-fe2e6acd79c3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='aspnetForm']/section[2]/div/div/div[2]</value>
      <webElementGuid>5388bd0d-175b-4289-a015-0c46ca5839f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::div[1]</value>
      <webElementGuid>af056bb8-b7c1-4b42-b010-fba2743346b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CHANAKYA-BUHS'])[1]/following::div[1]</value>
      <webElementGuid>50be77cf-c637-4198-9778-637d6ebd7326</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/div/div[2]</value>
      <webElementGuid>62646477-94ec-4ada-8e51-07f9e6996e34</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;
                        
                        
                            
                                
                            
                        
                        
                            
                            
                            
                                
                                    Home
                                

                                 
           
          About Us 
          
          

            History

            
                                            Aim
            
                                            Objectives

            
                                            About Our Logo
          
            
                                            Hon&quot; , &quot;'&quot; , &quot;ble Chancellor
              
            
           
                                            University Officers
            
                                            Authorities of University
              
                                            Organization Structure
              
                                            Directory
              
          
        


                            


                                
           
          Affilation 
          
          
            Affiliation Process
            Affiliation Notification
              Forms
              Affiliated College
            
              
          
        
                                 
           
          Academic 
          
          
           
            
                                            Faculties 

            
                                            Courses
               
                                            Download Syllabus
          
          
        

    
                                    
                                        Research 
                                    
                                    
                                        
                                            On Going Research Project 
                                        
                                            Research With Us
                                    
                                


                                
                                    
                                        Student Corner 
                                    
                                    
                                        
                                            Examination

                                        
                                        
                                            Registration

                                        
                                    
                                
                                
                                    
                                        Downloads 
                                    
                                    
                                        
                                            Act
                                        
                                            Notification Circular
                                        
                                        
                                            Office Order
                                        
                                            Forms
                                    
                                

                                
                                    Notice Board
                                    
                                
                                 
                                    Tenders
                                    
                                
                                
                                    Gallery
                                    
                                        
                                            Photo Gallery

                                    
                                
                               

                                
                                    Contacts
                                    
                                        
                                            Key Contacts
                                    
                                
                                 
                                    Recruitment
                                    
                                

                                
                                    Login
                                
                            


                        
                    &quot;) or . = concat(&quot;
                        
                        
                            
                                
                            
                        
                        
                            
                            
                            
                                
                                    Home
                                

                                 
           
          About Us 
          
          

            History

            
                                            Aim
            
                                            Objectives

            
                                            About Our Logo
          
            
                                            Hon&quot; , &quot;'&quot; , &quot;ble Chancellor
              
            
           
                                            University Officers
            
                                            Authorities of University
              
                                            Organization Structure
              
                                            Directory
              
          
        


                            


                                
           
          Affilation 
          
          
            Affiliation Process
            Affiliation Notification
              Forms
              Affiliated College
            
              
          
        
                                 
           
          Academic 
          
          
           
            
                                            Faculties 

            
                                            Courses
               
                                            Download Syllabus
          
          
        

    
                                    
                                        Research 
                                    
                                    
                                        
                                            On Going Research Project 
                                        
                                            Research With Us
                                    
                                


                                
                                    
                                        Student Corner 
                                    
                                    
                                        
                                            Examination

                                        
                                        
                                            Registration

                                        
                                    
                                
                                
                                    
                                        Downloads 
                                    
                                    
                                        
                                            Act
                                        
                                            Notification Circular
                                        
                                        
                                            Office Order
                                        
                                            Forms
                                    
                                

                                
                                    Notice Board
                                    
                                
                                 
                                    Tenders
                                    
                                
                                
                                    Gallery
                                    
                                        
                                            Photo Gallery

                                    
                                
                               

                                
                                    Contacts
                                    
                                        
                                            Key Contacts
                                    
                                
                                 
                                    Recruitment
                                    
                                

                                
                                    Login
                                
                            


                        
                    &quot;))]</value>
      <webElementGuid>1caa38b7-b2e3-47cb-a537-941e01017fc8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
